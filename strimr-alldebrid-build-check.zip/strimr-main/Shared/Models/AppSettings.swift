import AetherEngine
import Foundation

enum SpoilerProtectionLevel: String, Codable, CaseIterable, Hashable {
    case off
    case thumbnails
    case full

    var title: String {
        switch self {
        case .off:
            String(localized: "settings.interface.spoilerProtection.off")
        case .thumbnails:
            String(localized: "settings.interface.spoilerProtection.thumbnails")
        case .full:
            String(localized: "settings.interface.spoilerProtection.full")
        }
    }
}

enum ContinueWatchingAction: String, Codable, CaseIterable, Hashable {
    case openDetails
    case play

    var title: String {
        switch self {
        case .openDetails:
            String(localized: "settings.interface.continueWatchingAction.openDetails")
        case .play:
            String(localized: "settings.interface.continueWatchingAction.play")
        }
    }
}

enum LandscapeEpisodeArtwork: String, Codable, CaseIterable, Hashable {
    case episode
    case series

    var title: String {
        switch self {
        case .episode:
            String(localized: "settings.interface.seriesArtwork.landscape.episode")
        case .series:
            String(localized: "settings.interface.seriesArtwork.landscape.series")
        }
    }
}

enum PortraitEpisodeArtwork: String, Codable, CaseIterable, Hashable {
    case series
    case season

    var title: String {
        switch self {
        case .series:
            String(localized: "settings.interface.seriesArtwork.portrait.series")
        case .season:
            String(localized: "settings.interface.seriesArtwork.portrait.season")
        }
    }
}

/// What the hero at the top of the home shows.
enum HomeHeroSource: String, Codable, CaseIterable, Hashable {
    case discover
    case continueWatching
    case off

    var title: String {
        switch self {
        case .discover:
            String(localized: "settings.interface.homeHero.discover")
        case .continueWatching:
            String(localized: "settings.interface.homeHero.continueWatching")
        case .off:
            String(localized: "settings.interface.homeHero.off")
        }
    }
}

enum StartupScreen: String, Codable, CaseIterable, Hashable {
    case home
    case discover
    case search
    case downloads
    case libraries
    case liveTV
    case favorites

    static var selectableCases: [StartupScreen] {
        #if os(tvOS)
            allCases.filter { $0 != .downloads }
        #else
            allCases
        #endif
    }

    var title: String {
        switch self {
        case .home:
            String(localized: "tabs.home")
        case .discover:
            String(localized: "tabs.discover")
        case .search:
            String(localized: "tabs.search")
        case .downloads:
            String(localized: "downloads.title")
        case .libraries:
            String(localized: "tabs.libraries")
        case .liveTV:
            String(localized: "livetv.title")
        case .favorites:
            String(localized: "tabs.favorites")
        }
    }
}

enum TabBarPlacement: String, Codable, CaseIterable, Hashable {
    case top
    case sidebar

    var title: String {
        switch self {
        case .top:
            String(localized: "settings.interface.tabBarPlacement.top")
        case .sidebar:
            String(localized: "settings.interface.tabBarPlacement.sidebar")
        }
    }
}

enum PosterSize: String, Codable, CaseIterable, Hashable {
    case small
    case medium
    case large

    var title: String {
        switch self {
        case .small:
            String(localized: "settings.interface.posterSize.small")
        case .medium:
            String(localized: "settings.interface.posterSize.medium")
        case .large:
            String(localized: "settings.interface.posterSize.large")
        }
    }

    /// Multiplies the platform's default card sizes, so carousels and grids scale together.
    var scale: CGFloat {
        switch self {
        case .small: 0.72
        case .medium: 1
        case .large: 1.2
        }
    }

    var gridCardWidth: CGFloat {
        #if os(tvOS)
            (200 * scale).rounded()
        #else
            (112 * scale).rounded()
        #endif
    }
}

enum ThemeMusicVolume: String, Codable, CaseIterable, Hashable {
    case off
    case low
    case medium
    case high

    var level: Float {
        switch self {
        case .off: 0
        case .low: 0.15
        case .medium: 0.35
        case .high: 0.6
        }
    }

    var title: String {
        switch self {
        case .off:
            String(localized: "settings.interface.themeMusic.off")
        case .low:
            String(localized: "settings.interface.themeMusic.low")
        case .medium:
            String(localized: "settings.interface.themeMusic.medium")
        case .high:
            String(localized: "settings.interface.themeMusic.high")
        }
    }
}

enum SubtitleTextColor: String, Codable, CaseIterable, Hashable {
    case white
    case lightGray
    case cream
    case yellow
    case cyan
    case green
}

enum SubtitleBrightness: String, Codable, CaseIterable, Hashable {
    case full
    case high
    case medium
    case low
}

enum SubtitleFontWeight: String, Codable, CaseIterable, Hashable {
    case regular
    case medium
    case semibold
    case bold
}

enum SubtitleBackgroundStrength: String, Codable, CaseIterable, Hashable {
    case none
    case subtle
    case standard
    case strong
}

enum SubtitleEdgeStyle: String, Codable, CaseIterable, Hashable {
    case shadow
    case outline
    case none
}

enum SubtitleVerticalPosition: String, Codable, CaseIterable, Hashable {
    case bottom
    case middle
    case top
}

enum SubtitleBottomMargin: String, Codable, CaseIterable, Hashable {
    case automatic
    case percent0
    case percent2
    case percent4
    case percent6
    case percent8
    case percent10
    case percent15
    case percent20

    /// Nil keeps the player's default margin.
    var percent: Int? {
        switch self {
        case .automatic: nil
        case .percent0: 0
        case .percent2: 2
        case .percent4: 4
        case .percent6: 6
        case .percent8: 8
        case .percent10: 10
        case .percent15: 15
        case .percent20: 20
        }
    }
}

enum NextEpisodeAutoplay: String, Codable, CaseIterable, Hashable {
    case disabled
    case immediately
    case after5Seconds
    case after10Seconds
    case after15Seconds
    case after30Seconds

    var delaySeconds: Int? {
        switch self {
        case .disabled:
            nil
        case .immediately:
            0
        case .after5Seconds:
            5
        case .after10Seconds:
            10
        case .after15Seconds:
            15
        case .after30Seconds:
            30
        }
    }

    var isEnabled: Bool {
        self != .disabled
    }

    var title: String {
        switch self {
        case .disabled:
            String(localized: "settings.playback.nextEpisodeAutoplay.disabled")
        case .immediately:
            String(localized: "settings.playback.nextEpisodeAutoplay.immediately")
        case .after5Seconds:
            String(localized: "settings.playback.nextEpisodeAutoplay.after5Seconds")
        case .after10Seconds:
            String(localized: "settings.playback.nextEpisodeAutoplay.after10Seconds")
        case .after15Seconds:
            String(localized: "settings.playback.nextEpisodeAutoplay.after15Seconds")
        case .after30Seconds:
            String(localized: "settings.playback.nextEpisodeAutoplay.after30Seconds")
        }
    }
}

struct SubtitleAppearance: Equatable {
    let fontSize: Int
    let textColor: SubtitleTextColor
    let brightness: SubtitleBrightness
    let fontWeight: SubtitleFontWeight
    let backgroundStrength: SubtitleBackgroundStrength
    let edgeStyle: SubtitleEdgeStyle
    let verticalPosition: SubtitleVerticalPosition
    let bottomMargin: SubtitleBottomMargin
}

enum DialogueBoost: String, Codable, CaseIterable, Hashable, Identifiable {
    case off
    case light
    case strong

    var id: Self {
        self
    }

    var gainDB: Double {
        switch self {
        case .off: 0
        case .light: 4
        case .strong: 8
        }
    }

    var title: String {
        switch self {
        case .off:
            String(localized: "settings.playback.dialogueBoost.off")
        case .light:
            String(localized: "settings.playback.dialogueBoost.light")
        case .strong:
            String(localized: "settings.playback.dialogueBoost.strong")
        }
    }
}

struct SubtitleSearchPreferences: Codable, Equatable {
    /// Nil follows the device language until another one is chosen.
    var language: String?
    var hearingImpaired = false
    var forced = false
}

enum PlaybackReadAhead: String, Codable, CaseIterable, Hashable, Identifiable {
    case standard
    case extended
    case maximum

    var id: Self {
        self
    }

    /// Segments are about 4 s long. The engine stops a larger read-ahead once it fills its disk budget.
    var forwardBufferSegments: Int? {
        switch self {
        case .standard: nil
        case .extended: 75
        case .maximum: .max
        }
    }

    /// tvOS keeps the software decoder's read-ahead in a fixed 96 MB of memory, which ignores the window.
    var softwarePacketCacheStorage: SoftwarePacketCacheStorage {
        self == .standard ? .automatic : .disk
    }

    var title: String {
        switch self {
        case .standard:
            String(localized: "settings.playback.readAhead.standard")
        case .extended:
            String(localized: "settings.playback.readAhead.extended")
        case .maximum:
            String(localized: "settings.playback.readAhead.maximum")
        }
    }
}

struct PlaybackSettings: Codable, Equatable {
    var qualityPreset = TranscodeQualityPreset.original
    var nextEpisodeAutoplay = NextEpisodeAutoplay.after15Seconds
    /// Armed when the player opens. Nil leaves the sleep timer off.
    var defaultSleepTimer: SleepTimerMode?
    var videoScaleMode = PlayerVideoScaleMode.fit
    var autoRotateVideo = true
    var pictureInPicture = true
    var backgroundAudio = true
    var autoSkipIntros = false
    var autoSkipCredits = false
    var autoSkipCommercials = false
    var losslessAudio = false
    /// Nil keeps TrueHD Atmos and DTS:X on the channel bridge.
    var spatialAudioLayout: SpatialSpeakerLayout?
    var nightMode = false
    var dialogueBoost = DialogueBoost.off
    var rememberTrackSelections = true
    var showChaptersOnTimeline = true
    var showSkipSegmentsOnTimeline = false
    var showEndsAtTime = true
    var showClock = false
    var showInfoWhenPaused = true
    var showScrubThumbnailPreviews = true
    var generateMissingScrubThumbnailPreviews = true
    var styledASSSubtitles = true
    var showSubtitlesOnSkipBack = true
    var seekBackwardSeconds = 10
    var seekForwardSeconds = 10
    var doubleTapToSeek = true
    var defaultPlaybackRate: Float = 1.0
    var audioDelayMilliseconds = 0
    var subtitleFontSize = defaultSubtitleFontSize
    var subtitleTextColor = SubtitleTextColor.white
    var subtitleBrightness = SubtitleBrightness.full
    var subtitleFontWeight = SubtitleFontWeight.semibold
    var subtitleBackgroundStrength = SubtitleBackgroundStrength.standard
    var subtitleEdgeStyle = SubtitleEdgeStyle.shadow
    var subtitleVerticalPosition = SubtitleVerticalPosition.bottom
    var subtitleBottomMargin = SubtitleBottomMargin.automatic
    var subtitleSearch = SubtitleSearchPreferences()
    var automaticSubtitleSearch = false
    /// Nil plays in Strimr's built-in player.
    var externalPlayer: ExternalPlayerSelection?
    /// Kept apart from the selection so switching to another player does not lose the template.
    var customExternalPlayer: CustomExternalPlayer?
    /// Forces the server-side transcode for Live TV, the route used before the engine played broadcast streams.
    var transcodeLiveTV = false
    var readAhead = PlaybackReadAhead.standard

    init() {}

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        qualityPreset = try container.decodeIfPresent(
            TranscodeQualityPreset.self,
            forKey: .qualityPreset,
        ) ?? .original
        nextEpisodeAutoplay = try container.decodeIfPresent(
            NextEpisodeAutoplay.self,
            forKey: .nextEpisodeAutoplay,
        ) ?? .after15Seconds
        defaultSleepTimer = try? container.decodeIfPresent(SleepTimerMode.self, forKey: .defaultSleepTimer)
        videoScaleMode = (try? container.decodeIfPresent(PlayerVideoScaleMode.self, forKey: .videoScaleMode)) ?? .fit
        autoRotateVideo = try container.decodeIfPresent(Bool.self, forKey: .autoRotateVideo) ?? true
        pictureInPicture = (try? container.decodeIfPresent(Bool.self, forKey: .pictureInPicture)) ?? true
        backgroundAudio = (try? container.decodeIfPresent(Bool.self, forKey: .backgroundAudio)) ?? true
        autoSkipIntros = try container.decodeIfPresent(Bool.self, forKey: .autoSkipIntros) ?? false
        autoSkipCredits = try container.decodeIfPresent(Bool.self, forKey: .autoSkipCredits) ?? false
        autoSkipCommercials = try container.decodeIfPresent(Bool.self, forKey: .autoSkipCommercials) ?? false
        losslessAudio = try container.decodeIfPresent(Bool.self, forKey: .losslessAudio) ?? false
        spatialAudioLayout = try? container.decodeIfPresent(
            SpatialSpeakerLayout.self,
            forKey: .spatialAudioLayout,
        )
        nightMode = (try? container.decodeIfPresent(Bool.self, forKey: .nightMode)) ?? false
        dialogueBoost = (try? container.decodeIfPresent(DialogueBoost.self, forKey: .dialogueBoost)) ?? .off
        rememberTrackSelections = try container.decodeIfPresent(
            Bool.self,
            forKey: .rememberTrackSelections,
        ) ?? true
        showChaptersOnTimeline = try container.decodeIfPresent(
            Bool.self,
            forKey: .showChaptersOnTimeline,
        ) ?? true
        showSkipSegmentsOnTimeline = try container.decodeIfPresent(
            Bool.self,
            forKey: .showSkipSegmentsOnTimeline,
        ) ?? false
        showEndsAtTime = try container.decodeIfPresent(
            Bool.self,
            forKey: .showEndsAtTime,
        ) ?? true
        showClock = try container.decodeIfPresent(Bool.self, forKey: .showClock) ?? false
        showInfoWhenPaused = try container.decodeIfPresent(Bool.self, forKey: .showInfoWhenPaused) ?? true
        showScrubThumbnailPreviews = try container.decodeIfPresent(
            Bool.self,
            forKey: .showScrubThumbnailPreviews,
        ) ?? true
        generateMissingScrubThumbnailPreviews = try container.decodeIfPresent(
            Bool.self,
            forKey: .generateMissingScrubThumbnailPreviews,
        ) ?? true
        styledASSSubtitles = try container.decodeIfPresent(Bool.self, forKey: .styledASSSubtitles) ?? true
        showSubtitlesOnSkipBack = try container.decodeIfPresent(
            Bool.self,
            forKey: .showSubtitlesOnSkipBack,
        ) ?? true
        automaticSubtitleSearch = try container.decodeIfPresent(
            Bool.self,
            forKey: .automaticSubtitleSearch,
        ) ?? false
        seekBackwardSeconds = try container.decodeIfPresent(Int.self, forKey: .seekBackwardSeconds) ?? 10
        seekForwardSeconds = try container.decodeIfPresent(Int.self, forKey: .seekForwardSeconds) ?? 10
        doubleTapToSeek = try container.decodeIfPresent(Bool.self, forKey: .doubleTapToSeek) ?? true
        let decodedRate = (try? container.decodeIfPresent(Float.self, forKey: .defaultPlaybackRate)) ?? 1.0
        defaultPlaybackRate = PlaybackSpeedOptions.all.contains { $0.rate == decodedRate } ? decodedRate : 1.0
        audioDelayMilliseconds = PlaybackOffsetRange.audio.clamp(
            (try? container.decodeIfPresent(Int.self, forKey: .audioDelayMilliseconds)) ?? 0,
        )
        subtitleFontSize = (try? container.decode(Int.self, forKey: .subtitleFontSize))
            ?? Self.defaultSubtitleFontSize
        subtitleTextColor = (try? container.decode(SubtitleTextColor.self, forKey: .subtitleTextColor))
            ?? .white
        subtitleBrightness = (try? container.decode(SubtitleBrightness.self, forKey: .subtitleBrightness))
            ?? .full
        subtitleFontWeight = (try? container.decode(SubtitleFontWeight.self, forKey: .subtitleFontWeight))
            ?? .semibold
        subtitleBackgroundStrength = (
            try? container.decode(SubtitleBackgroundStrength.self, forKey: .subtitleBackgroundStrength),
        )
            ?? .standard
        subtitleEdgeStyle = (try? container.decode(SubtitleEdgeStyle.self, forKey: .subtitleEdgeStyle))
            ?? .shadow
        subtitleVerticalPosition = (
            try? container.decode(SubtitleVerticalPosition.self, forKey: .subtitleVerticalPosition),
        )
            ?? .bottom
        subtitleBottomMargin = (
            try? container.decode(SubtitleBottomMargin.self, forKey: .subtitleBottomMargin),
        )
            ?? .automatic
        subtitleSearch = (try? container.decode(SubtitleSearchPreferences.self, forKey: .subtitleSearch))
            ?? SubtitleSearchPreferences()
        externalPlayer = try? container.decodeIfPresent(ExternalPlayerSelection.self, forKey: .externalPlayer)
        customExternalPlayer = try? container.decodeIfPresent(
            CustomExternalPlayer.self,
            forKey: .customExternalPlayer,
        )
        transcodeLiveTV = (try? container.decodeIfPresent(Bool.self, forKey: .transcodeLiveTV)) ?? false
        readAhead = (try? container.decodeIfPresent(PlaybackReadAhead.self, forKey: .readAhead)) ?? .standard
    }

    var audioShaping: AudioShaping {
        AudioShaping(dialogueGainDB: dialogueBoost.gainDB, compressor: nightMode ? .night : nil)
    }

    var resolvedExternalPlayer: ExternalPlayer? {
        ExternalPlayer(selection: externalPlayer, custom: customExternalPlayer)
    }

    var subtitleAppearance: SubtitleAppearance {
        SubtitleAppearance(
            fontSize: subtitleFontSize,
            textColor: subtitleTextColor,
            brightness: subtitleBrightness,
            fontWeight: subtitleFontWeight,
            backgroundStrength: subtitleBackgroundStrength,
            edgeStyle: subtitleEdgeStyle,
            verticalPosition: subtitleVerticalPosition,
            bottomMargin: subtitleBottomMargin,
        )
    }

    mutating func resetSubtitleAppearance() {
        subtitleFontSize = Self.defaultSubtitleFontSize
        subtitleTextColor = .white
        subtitleBrightness = .full
        subtitleFontWeight = .semibold
        subtitleBackgroundStrength = .standard
        subtitleEdgeStyle = .shadow
        subtitleVerticalPosition = .bottom
        subtitleBottomMargin = .automatic
    }

    private static var defaultSubtitleFontSize: Int {
        #if os(tvOS)
            32
        #else
            20
        #endif
    }
}

struct InterfaceSettings: Codable, Equatable {
    var homeRowsByProfile: [String: HomeRowPreferences] = [:]
    var librariesByProfile: [String: LibraryPreferences] = [:]
    // Pre-multi-server settings, only read by the migration and cleared once it succeeds.
    var hiddenLibraryIds: [String] = []
    var navigationLibraryIds: [String] = []
    var homeRowsByScope: [String: HomeRowPreferences] = [:]
    var displayCollections = true
    var displayPlaylists = true
    var displayFavoritesTab = false
    var displayDownloadsTab = false
    var displayLiveTVTab = true
    var displaySeerrDiscoverTab = true
    var multiServerSearchEnabled: Bool?
    var groupsSearchResults = true
    var spoilerProtection = SpoilerProtectionLevel.off
    var landscapeEpisodeArtwork = LandscapeEpisodeArtwork.episode
    var portraitEpisodeArtwork = PortraitEpisodeArtwork.series
    var libraryBrowseByKey: [String: LibraryBrowsePreferences] = [:]
    var libraryDefaultLayout = LibraryDefaultLayout.automatic
    var posterSize = PosterSize.medium
    var themeMusicVolume = ThemeMusicVolume.off
    var showsTitleLogo = true
    var showsCardLabels = true
    var showsWatchStatusBadges = true
    var continueWatchingAction = ContinueWatchingAction.openDetails
    /// Jellyfin keeps Next Up apart; Plex already shows a single row.
    var mergesNextUpIntoContinueWatching = false
    var homeHero = HomeHeroSource.discover
    var homeHeroIncludesTrending = true
    var tabBarPlacement = TabBarPlacement.top
    var startupScreen = StartupScreen.home
    var tintsLiveTVGuideCategories = true
    var liveTVSectionByServer: [String: String] = [:]
    var liveTVChannelSortByServer: [String: LiveTVChannelSort] = [:]

    init() {}

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        homeRowsByProfile = (try? container.decode(
            [String: HomeRowPreferences].self,
            forKey: .homeRowsByProfile,
        )) ?? [:]
        librariesByProfile = (try? container.decode(
            [String: LibraryPreferences].self,
            forKey: .librariesByProfile,
        )) ?? [:]
        hiddenLibraryIds = try container.decodeIfPresent([String].self, forKey: .hiddenLibraryIds) ?? []
        navigationLibraryIds = try container.decodeIfPresent([String].self, forKey: .navigationLibraryIds) ?? []
        homeRowsByScope = try container.decodeIfPresent(
            [String: HomeRowPreferences].self,
            forKey: .homeRowsByScope,
        ) ?? [:]
        displayCollections = try container.decodeIfPresent(Bool.self, forKey: .displayCollections) ?? true
        displayPlaylists = try container.decodeIfPresent(Bool.self, forKey: .displayPlaylists) ?? true
        displayFavoritesTab = try container.decodeIfPresent(Bool.self, forKey: .displayFavoritesTab) ?? false
        displayDownloadsTab = try container.decodeIfPresent(Bool.self, forKey: .displayDownloadsTab) ?? false
        displayLiveTVTab = try container.decodeIfPresent(Bool.self, forKey: .displayLiveTVTab) ?? true
        displaySeerrDiscoverTab = try container.decodeIfPresent(Bool.self, forKey: .displaySeerrDiscoverTab) ?? true
        multiServerSearchEnabled = try container.decodeIfPresent(Bool.self, forKey: .multiServerSearchEnabled)
        groupsSearchResults = try container.decodeIfPresent(Bool.self, forKey: .groupsSearchResults) ?? true
        spoilerProtection = (try? container.decode(SpoilerProtectionLevel.self, forKey: .spoilerProtection)) ?? .off
        landscapeEpisodeArtwork = (try? container.decode(
            LandscapeEpisodeArtwork.self,
            forKey: .landscapeEpisodeArtwork,
        )) ?? .episode
        portraitEpisodeArtwork = (try? container.decode(
            PortraitEpisodeArtwork.self,
            forKey: .portraitEpisodeArtwork,
        )) ?? .series
        libraryBrowseByKey = (try? container.decode(
            [String: LibraryBrowsePreferences].self,
            forKey: .libraryBrowseByKey,
        )) ?? [:]
        libraryDefaultLayout = (try? container.decode(
            LibraryDefaultLayout.self,
            forKey: .libraryDefaultLayout,
        )) ?? .automatic
        posterSize = (try? container.decode(PosterSize.self, forKey: .posterSize)) ?? .medium
        themeMusicVolume = (try? container.decode(ThemeMusicVolume.self, forKey: .themeMusicVolume)) ?? .off
        showsTitleLogo = try container.decodeIfPresent(Bool.self, forKey: .showsTitleLogo) ?? true
        showsCardLabels = try container.decodeIfPresent(Bool.self, forKey: .showsCardLabels) ?? true
        showsWatchStatusBadges = try container.decodeIfPresent(Bool.self, forKey: .showsWatchStatusBadges) ?? true
        continueWatchingAction = (try? container.decode(
            ContinueWatchingAction.self,
            forKey: .continueWatchingAction,
        )) ?? .openDetails
        mergesNextUpIntoContinueWatching = try container.decodeIfPresent(
            Bool.self,
            forKey: .mergesNextUpIntoContinueWatching,
        ) ?? false
        homeHero = (try? container.decode(HomeHeroSource.self, forKey: .homeHero)) ?? .discover
        homeHeroIncludesTrending = try container.decodeIfPresent(Bool.self, forKey: .homeHeroIncludesTrending) ?? true
        tabBarPlacement = (try? container.decode(TabBarPlacement.self, forKey: .tabBarPlacement)) ?? .top
        startupScreen = (try? container.decode(StartupScreen.self, forKey: .startupScreen)) ?? .home
        tintsLiveTVGuideCategories = (try? container.decodeIfPresent(
            Bool.self,
            forKey: .tintsLiveTVGuideCategories,
        )) ?? true
        liveTVSectionByServer = (try? container.decodeIfPresent(
            [String: String].self,
            forKey: .liveTVSectionByServer,
        )) ?? [:]
        liveTVChannelSortByServer = (try? container.decodeIfPresent(
            [String: LiveTVChannelSort].self,
            forKey: .liveTVChannelSortByServer,
        )) ?? [:]
    }
}

struct DownloadSettings: Codable, Equatable {
    var wifiOnly = true
    var qualityPreset = TranscodeQualityPreset.original
    /// Ceiling of the offline browsing cache, in megabytes.
    var offlineCacheLimitMB = 500

    init() {}

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        wifiOnly = try container.decodeIfPresent(Bool.self, forKey: .wifiOnly) ?? true
        offlineCacheLimitMB = try container.decodeIfPresent(Int.self, forKey: .offlineCacheLimitMB) ?? 500
        qualityPreset = try container.decodeIfPresent(
            TranscodeQualityPreset.self,
            forKey: .qualityPreset,
        ) ?? .original
    }
}

struct AppSettings: Codable, Equatable {
    var playback = PlaybackSettings()
    var interface = InterfaceSettings()
    var downloads = DownloadSettings()

    init() {}

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        playback = try container.decodeIfPresent(PlaybackSettings.self, forKey: .playback) ?? PlaybackSettings()
        interface = try container.decodeIfPresent(InterfaceSettings.self, forKey: .interface) ?? InterfaceSettings()
        downloads = try container.decodeIfPresent(DownloadSettings.self, forKey: .downloads) ?? DownloadSettings()
    }
}
