import Foundation

@MainActor
extension Hub {
    init(plexHub: PlexHub, server: ServerIdentity) {
        self.init(
            id: plexHub.hubIdentifier,
            key: plexHub.key,
            hubKey: plexHub.hubKey,
            title: plexHub.title,
            size: plexHub.size,
            more: plexHub.more,
            items: (plexHub.metadata ?? [])
                .filter(\.type.isSupported)
                .compactMap { MediaDisplayItem(plexItem: $0, server: server) },
            server: server,
        )
    }
}
