import SwiftUI

extension MediaChapter {
    var displayTitle: String {
        title.isEmpty ? String(localized: "player.chapters.number \(index)") : title
    }

    var startTimeText: String {
        playerTimestampText(startTime)
    }

    func accessibilityDescription(totalCount: Int, isCurrent: Bool) -> String {
        if isCurrent {
            return String(
                localized: "player.chapters.accessibility.current \(index) \(totalCount) \(startTimeText)",
            )
        }
        return String(
            localized: "player.chapters.accessibility \(index) \(totalCount) \(startTimeText)",
        )
    }
}

struct PlayerChapterArtworkView: View {
    @Environment(MediaServices.self) private var services: MediaServices?

    var artworkPath: String?
    var width: Int
    var height: Int

    @State private var resource: ArtworkResource?
    @State private var isLoading = false

    var body: some View {
        Group {
            if let resource {
                ArtworkResourceView(resource: resource)
            } else if isLoading {
                ProgressView()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                placeholder
            }
        }
        .clipped()
        .task(id: loadID) {
            await loadArtwork()
        }
    }

    private var loadID: String {
        "\(artworkPath ?? "")|\(width)x\(height)"
    }

    private func loadArtwork() async {
        resource = nil
        guard let artworkPath, let services else {
            isLoading = false
            return
        }

        isLoading = true
        do {
            let loadedResource = try await services.artwork.artwork(
                path: artworkPath,
                width: width,
                height: height,
            )
            guard !Task.isCancelled else { return }
            resource = loadedResource
            isLoading = false
        } catch {
            guard !Task.isCancelled, !error.isCancellation else { return }
            resource = nil
            isLoading = false
        }
    }

    private var placeholder: some View {
        ZStack {
            Color.surfaceSubtle
            Image(systemName: "film")
                .font(.title2)
                .foregroundStyle(.textTertiary)
        }
    }
}

struct PlayerSegmentedTimelineRail: View {
    var chapters: [MediaChapter]
    var skipSegments: [SkipSegment] = []
    var duration: Double?
    var position: Double
    var bufferedEnd: Double
    var horizontalInset: CGFloat = 14
    var trackHeight: CGFloat = 4
    var preferredGap: CGFloat = 4

    private let minimumGap: CGFloat = 2

    var body: some View {
        GeometryReader { proxy in
            let timelineDuration = effectiveDuration
            let rects = segmentRects(
                width: proxy.size.width,
                duration: timelineDuration,
            )
            let playedX = timelineX(
                for: position,
                width: proxy.size.width,
                duration: timelineDuration,
            )
            let bufferedX = timelineX(
                for: bufferedEnd,
                width: proxy.size.width,
                duration: timelineDuration,
            )

            let segmentSpans = skipSegmentSpans(width: proxy.size.width)

            ForEach(Array(rects.enumerated()), id: \.offset) { _, rect in
                ZStack(alignment: .leading) {
                    Color.progressTrack

                    Color.progressBuffered
                        .frame(width: fillWidth(endingAt: bufferedX, in: rect))

                    Color.progressFill
                        .frame(width: fillWidth(endingAt: playedX, in: rect))

                    ForEach(Array(segmentSpans.enumerated()), id: \.offset) { _, span in
                        let minX = max(span.lowerBound, rect.minX)
                        let maxX = min(span.upperBound, rect.maxX)
                        if maxX > minX {
                            Color.progressSegment
                                .frame(width: maxX - minX)
                                .offset(x: minX - rect.minX)
                        }
                    }
                }
                .frame(width: rect.width, height: trackHeight)
                .clipShape(Capsule())
                .position(x: rect.midX, y: proxy.size.height / 2)
            }
        }
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }

    private var effectiveDuration: Double {
        if let duration, duration.isFinite, duration > 0 {
            return duration
        }

        let knownExtent = [position, bufferedEnd]
            .filter { $0.isFinite && $0 > 0 }
            .max() ?? 0
        return max(knownExtent, 1)
    }

    private func segmentRects(width: CGFloat, duration: Double) -> [CGRect] {
        let usableWidth = max(width - horizontalInset * 2, 0)
        guard usableWidth > 0 else { return [] }

        let hasKnownDuration = self.duration.map {
            $0.isFinite && $0 > 0
        } ?? false
        let validStarts = hasKnownDuration
            ? chapters
            .filter(\.isValid)
            .map(\.startTime)
            .filter { $0.isFinite && $0 > 0 && $0 < duration }
            .sorted()
            : []

        var distinctStarts: [Double] = []
        for start in validStarts {
            if let previous = distinctStarts.last,
               abs(start - previous) < 0.001
            {
                continue
            }
            distinctStarts.append(start)
        }

        let candidateBoundaries = [horizontalInset]
            + distinctStarts.map { start in
                horizontalInset + usableWidth * CGFloat(start / duration)
            }
            + [horizontalInset + usableWidth]
        let minimumSpan = trackHeight + minimumGap
        var boundaries = [candidateBoundaries[0]]

        for boundary in candidateBoundaries.dropFirst().dropLast() {
            guard let previous = boundaries.last,
                  boundary - previous >= minimumSpan,
                  horizontalInset + usableWidth - boundary >= minimumSpan
            else {
                continue
            }
            boundaries.append(boundary)
        }
        boundaries.append(horizontalInset + usableWidth)

        let spans = zip(boundaries, boundaries.dropFirst()).map { $1 - $0 }
        let smallestSpan = spans.min() ?? usableWidth
        let gap = min(preferredGap, max(minimumGap, smallestSpan - trackHeight))
        let lastSegmentIndex = boundaries.count - 2

        return (0 ... lastSegmentIndex).compactMap { index in
            let leadingGap = index == 0 ? 0 : gap / 2
            let trailingGap = index == lastSegmentIndex ? 0 : gap / 2
            let minX = boundaries[index] + leadingGap
            let maxX = boundaries[index + 1] - trailingGap
            guard maxX > minX else { return nil }
            return CGRect(
                x: minX,
                y: 0,
                width: maxX - minX,
                height: trackHeight,
            )
        }
    }

    private func skipSegmentSpans(width: CGFloat) -> [ClosedRange<CGFloat>] {
        guard let knownDuration = duration, knownDuration.isFinite, knownDuration > 0, !skipSegments.isEmpty else {
            return []
        }
        return skipSegments
            .filter { $0.startTime.isFinite && $0.endTime.isFinite && $0.endTime > $0.startTime }
            .map { segment in
                timelineX(for: segment.startTime, width: width, duration: knownDuration)
                    ... timelineX(for: segment.endTime, width: width, duration: knownDuration)
            }
    }

    private func timelineX(for time: Double, width: CGFloat, duration: Double) -> CGFloat {
        let usableWidth = max(width - horizontalInset * 2, 0)
        let safeTime = time.isFinite ? time : 0
        let progress = CGFloat(min(max(safeTime / duration, 0), 1))
        return horizontalInset + usableWidth * progress
    }

    private func fillWidth(endingAt x: CGFloat, in rect: CGRect) -> CGFloat {
        min(max(x - rect.minX, 0), rect.width)
    }
}

func playerTimestampText(_ value: Double) -> String {
    guard value.isFinite, value >= 0 else { return "0:00" }
    let totalSeconds = Int(value.rounded())
    let hours = totalSeconds / 3600
    let minutes = (totalSeconds % 3600) / 60
    let seconds = totalSeconds % 60

    if hours > 0 {
        return String(format: "%d:%02d:%02d", hours, minutes, seconds)
    }
    return String(format: "%d:%02d", minutes, seconds)
}
