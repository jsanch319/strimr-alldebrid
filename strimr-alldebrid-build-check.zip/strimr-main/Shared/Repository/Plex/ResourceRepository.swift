import Foundation

final class ResourceRepository {
    private let network: PlexCloudNetworkClient
    private weak var context: PlexAPIContext?

    init(context: PlexAPIContext) {
        self.context = context
        network = PlexCloudNetworkClient(
            authToken: context.authTokenCloud,
            clientIdentifier: context.clientIdentifier,
            session: context.session,
        )
    }

    func getResources() async throws -> [PlexCloudResource] {
        try await network.request(
            path: "/resources",
            method: "GET",
            queryItems: [
                URLQueryItem(name: "includeHttps", value: "1"),
                URLQueryItem(name: "includeRelay", value: "1"),
            ],
        )
    }

    func getAvailableResources() async throws -> [PlexCloudResource] {
        try await getResources().filter { ResourceRepository.isSelectable($0) }
    }

    private static func isSelectable(_ resource: PlexCloudResource) -> Bool {
        let hasConnections = !(resource.connections?.isEmpty ?? true)
        let hasAccessToken = resource.accessToken != nil
        return hasConnections && hasAccessToken
    }
}
